package br.com.servicos.spring.springproject.service;

public class BerryService {
    
}
