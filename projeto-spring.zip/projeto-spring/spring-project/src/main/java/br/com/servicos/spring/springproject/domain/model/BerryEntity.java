package br.com.servicos.spring.springproject.domain.model;

public class BerryEntity {
    
}
