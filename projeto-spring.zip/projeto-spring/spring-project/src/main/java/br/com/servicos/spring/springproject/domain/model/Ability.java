package br.com.servicos.spring.springproject.domain.model;

public class Ability {
    private long id;
    private String name;
}
