package br.com.servicos.spring.springproject.domain.model;

public enum Type {
    
}
