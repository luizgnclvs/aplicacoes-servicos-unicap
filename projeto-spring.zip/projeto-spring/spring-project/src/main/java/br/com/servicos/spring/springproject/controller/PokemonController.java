package br.com.servicos.spring.springproject.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PokemonController {
    
}
